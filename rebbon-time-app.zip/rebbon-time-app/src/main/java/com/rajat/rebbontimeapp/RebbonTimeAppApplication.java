package com.rajat.rebbontimeapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RebbonTimeAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RebbonTimeAppApplication.class, args);
	}
}
