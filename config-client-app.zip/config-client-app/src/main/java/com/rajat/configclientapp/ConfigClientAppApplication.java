package com.rajat.configclientapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigClientAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigClientAppApplication.class, args);
	}
}
