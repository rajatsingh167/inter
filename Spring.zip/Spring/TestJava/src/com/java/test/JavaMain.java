package com.java.test;

import java.util.HashMap;
import java.util.Map;

public class JavaMain {

	public static void main(String[] args) {
			
		System.out.println(new JavaMain().runLength("AABBAAAAACCCCDDDEASSDDD"));

	}

	public static String runLength(String plain) {
		  StringBuilder dest = new StringBuilder();
		  for (int i = 0; i < plain.length(); i++) {
		    int runLength = 1;
		    while (i+1 < plain.length() &&
		           plain.charAt(i) == plain.charAt(i+1)) {
		      runLength++;
		      i++;
		    }
		    dest.append(runLength);
		    dest.append(plain.charAt(i));
		  }
		  return dest.toString();
		}
	
	
	public class Bank {
	    // Singleton implementation omitted for brevity's sake

	    // map from account number to balance
	    private Map<String, Integer> accounts = new HashMap<>();

	    public int deposit(String account, int sum) throws IllegalArgumentException {
	        if (sum < 0) { 
	        	throw new IllegalArgumentException("sum cannot be negative"); 
	        	}
	        return accounts.put(account, accounts.get(account) + sum); 
	        } 
	    
	    public int withdraw(String account, int sum) 
	    { if (sum > accounts.get(account)) {
	            return -1;
	        }
	        accounts.put(account, accounts.get(account) - sum);
	        return sum;
	    }
	}
	
}
