package com.cg.rajat.SpringSecurityWithRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityWithRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityWithRestApplication.class, args);
	}
}
