
create table User
(
   id integer not null,
   name varchar(255) not null,
   Role varchar(255) not null,
   primary key(id)
);