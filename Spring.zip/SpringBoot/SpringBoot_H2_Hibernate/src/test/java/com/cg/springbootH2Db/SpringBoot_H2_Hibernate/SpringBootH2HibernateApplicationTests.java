package com.cg.springbootH2Db.SpringBoot_H2_Hibernate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBootH2HibernateApplicationTests {

	@Test
	public void contextLoads() {
	}

}
