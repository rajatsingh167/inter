package com.cg.jUnitTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;

public class TestAssertClass {

	@Test
	public void testAssertEqual() {
		String str = "Junit is working fine";
		// check for equality
		assertEquals("Junit is working fine", str);

	}

	@Test
	public void testAssertFalse() {
		int num = 5;
		// check for false condition
		assertFalse(num > 6);

	}

	@Test
	public void testAssertNotNull() {
		String str = "Hi";
		// check for not null value
		assertNotNull(str);
	}
	
	@Test
	public void testAssertNull() {
		String str = null;
		assertNull(str);
		
	}
	
	@Test
	public void testAssertTrue() {
		boolean test= true;
		assertTrue(test);
	}

}
