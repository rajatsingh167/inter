package com.cg.jUnitTest;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import com.cg.TestSuite.JuintTestSuite;

public class TestRunner {

	public static void main(String[] args) {
		
		Result result = JUnitCore.runClasses(JuintTestSuite.class);
		
		for(Failure failure :result.getFailures()) {
			System.out.println(failure.toString());
		}
		System.out.println("jh == > "+result.wasSuccessful());

	}

}
