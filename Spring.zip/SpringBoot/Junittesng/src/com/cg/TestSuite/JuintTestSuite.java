package com.cg.TestSuite;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.cg.jUnitTest.TestJunit;
import com.cg.jUnitTest.TestJunit1;
import com.cg.jUnitTest.TestJunit2;

@RunWith(Suite.class)
@Suite.SuiteClasses({ TestJunit.class,TestJunit1.class , TestJunit2.class})
public class JuintTestSuite {
		
	@Test
		public void Test() {
			System.out.println("inside juint test suite class");
		}
}
