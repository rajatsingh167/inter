package com.cg.springJdbcH2.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.springJdbcH2.model.ApiRequest;

@Repository
public class ApiRequestDao {

	@PersistenceContext
	EntityManager entityManager;

	public void create(ApiRequest apiRequest) {
		System.out.println("Daoo " +apiRequest);

		entityManager.persist(apiRequest);
	}
	
	public void update(ApiRequest apiRequest) {
		entityManager.merge(apiRequest);
	}
	
	public ApiRequest  getApiRequestById(Long id) {
		return entityManager.find(ApiRequest.class, id);
	}

	public void deleteApiRequestById(Long id) {
		ApiRequest apiRequest = getApiRequestById(id);
		if (apiRequest != null) {

		entityManager.remove(apiRequest);
		}
	}
}
