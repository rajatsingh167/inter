package com.cg.springJdbcH2.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "api_request")
public class ApiRequest {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Id;

	@Column(name = "request_time")
	private Date requestTime;

	public ApiRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiRequest( Date requestTime) {
		super();
		this.requestTime = requestTime;
	}
	
	

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public Date getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}

	@Override
	public String toString() {
		return "ApiRequest [Id=" + Id + ", requestTime=" + requestTime + "]";
	}

	
	
}
