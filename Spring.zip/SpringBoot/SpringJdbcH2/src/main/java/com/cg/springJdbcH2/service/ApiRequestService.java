package com.cg.springJdbcH2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.springJdbcH2.Dao.ApiRequestDao;
import com.cg.springJdbcH2.model.ApiRequest;

@Service
@Transactional
public class ApiRequestService {

	@Autowired
	 private ApiRequestDao apiRequestDao;
	
	public void create(ApiRequest apiRequest) {
		System.out.println("test" + apiRequest);
	apiRequestDao.create(apiRequest);
	}
}
