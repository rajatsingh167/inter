package com.cg.springJdbcH2.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springJdbcH2.model.ApiRequest;
import com.cg.springJdbcH2.service.ApiRequestService;

@RestController
@EnableAutoConfiguration
public class ApiController {

	@Autowired
	private ApiRequestService apiRequestService;
	
	private static final Logger logger = LoggerFactory.getLogger(ApiController.class);
	
	@RequestMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, String> getHome() {
		 logger.info("Api request received");
		 Map<String, String> response = new HashMap<String, String>();
		 try {
			  ApiRequest apiRequest = new ApiRequest(new Date());
			  System.out.println(apiRequest);
			  apiRequestService.create(apiRequest);
			  response.put("status", "success");
		 }catch(Exception e) {
			 logger.error("Error occurred while trying to process api request", e);
			 response.put("status", "fail");

		 }
		 return response;

	}


}
