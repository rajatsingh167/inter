package com.easy;

import java.beans.FeatureDescriptor;
import java.util.Scanner;

public class fibonacciSeries {

	/* Write a program to find fibonacci series */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		fibonacciSeries fs = new fibonacciSeries();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Range till you want fibonency series==> ");
		int n = sc.nextInt();
		fs.getFibonencySeries(n);
	}

	public void getFibonencySeries(int n) {
		int temp1 = 0;
		int sum = 0;
		int temp2 = 1;
		System.out.print(0 + " ");
		for (int i = 1; i <= n; i++) {

			sum = temp1 + temp2;
			temp1 = temp2;
			temp2 = sum;
			System.out.print(temp1 + " ");

		}

	}

}
