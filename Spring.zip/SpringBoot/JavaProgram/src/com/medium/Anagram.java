package com.medium;

import java.util.Scanner;

/*
 * Given set of 3 words namely (dog,god,cat) check if they are anagram, if yes put in one list and if no put in other 
 * list and display its count. In simple find anagrams.*/
public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter First String == > ");
		String str1 = sc.next();
		System.out.print("Enter Second String == > ");
		String str2 = sc.next();
		System.out.print("Enter Third String == > ");
		String str3 = sc.next();
		new Anagram().testAnagram(str1, str2, str3);

	}

	public void testAnagram(String str1, String str2, String str3) {
		
		if((str1.length() != str2.length()) && (str2.length()!= str3.length())) {
			System.out.println("Not a anagram ");
		}else {
			
			
		}

	}

}
