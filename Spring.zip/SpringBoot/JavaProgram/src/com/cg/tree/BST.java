package com.cg.tree;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class BST {

	public static void main(String[] args) {
		
		Node root = new Node(8);
        root.left = new Node(3);
        root.right = new Node(5);
        root.left.left = new Node(10);
        root.left.right = new Node(2);
        root.right.left = new Node(4);
        root.right.right = new Node(6);

        // traverse the binary tree and store its keys in a set
        Set<Integer> set = new TreeSet<>();
        extractkey(root, set);

        // put back keys present in set in their correct order in BST
        Iterator<Integer> it = set.iterator();
        convertToBST(root, it);

        // print the BST
        inorder(root); 

	}
	
	
	public static void inorder(Node root) {		
		if(root==null) {
			return;
		}
		inorder(root.left);
		System.out.println(root.data+ "   ");
		inorder(root.right);		
	}
	
	
	public static void extractkey(Node root , Set set) {
		
		if(root==null) {
			return;
		}
		extractkey(root.left, set);
		set.add(root.data);
		extractkey(root.right, set);
	}
	
	public  static void convertToBST(Node root , Iterator<Integer> it) {
		if(root == null) {
			return;
		}
		
		convertToBST(root.left, it);
		root.data=it.next();
		convertToBST(root.right, it);
		
	}

}


class Node
{
	int data;
	Node left=null, right=null;
	
	Node(int data){
		this.data=data;
	}
	
}